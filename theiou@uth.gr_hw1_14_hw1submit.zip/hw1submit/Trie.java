package ce326.hw1;

/**
 *
 * @author BASILIS
 */

public class Trie {
    
    //root of the trie
    public final TrieNode root;
    String dot;
    String str1 = "";
    
    
    public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    
    String[] words;
    public Trie(String []words) {
        root = new TrieNode();
        this.words = words;
        for(int i = 0; words[i] != null; i++) {
            add(words[i]);
        }
    }
    
    //check if the given word exists with method "contains".
    //If not then add it.
    public boolean add(String word) {
        TrieNode current = root;
        if(contains(word)) {
           return false;
        }
        
        int i;
        for(i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            int position = c - 'a';
            TrieNode node = current;
            if(node.children[position] == null) {
                node.children[position] = new TrieNode();
            }
            current = node.children[position];
        }
        current.isTerminal = true;
        return true;
    }
    
    //check if the given word is in the trie.
    public boolean contains(String word) {
        TrieNode current = root;
        int i;
        
        for(i = 0; i < word.length(); i++){
            char c = word.charAt(i);
            int position = c - 'a';
            TrieNode node = current;
            if(node.children[position] == null) {
                return false;
            }
            current = node.children[position];
        }
        return current.isTerminal;
    }
    
    //count the number of the words in the trie
    public int size() {
       TrieNode current = root;
       int result = 0;
       result = Search(current);
       return result;
    }
    //used in size
    private int Search(TrieNode curr) {
        int words = 0;
        int i;
        
        if(curr.isTerminal == true) {
            words++;
        }
        
        for(i = 0; i < 26; i++) {
            if(curr.children[i] != null) {
                char c = ALPHABET.charAt(i);
                words += Search(curr.children[i]);
            }
        }
        return words;
    }
    
    //return all the words with the given prefix
    public String[] wordsOfPrefix(String prefix) {
     TrieNode current = root;
     String []arr = new String[1000];
      for(char c : prefix.toCharArray()) {
          int position = c - 'a';
          if(current.children[position] != null) {
              current = current.children[position];
          }
      }
     char[] array;
     array = prefix.toCharArray();
     char[] buff = new char[100];
     System.arraycopy(array, 0, buff, 0, prefix.length());
     findWords(current,arr, buff, prefix.length());
     return arr;
    }
    
    //used in wordsOfprefix
    private void findWords(TrieNode curr, String []arr, char[] array, int tmp) {
       
        if(curr.isTerminal) {
            String str = "";
            for(int i = 0; array[i] != 0; i++) {
              str += array[i];  
            } 
            int j;
            for(j = 0; arr[j] != null; j++) {
            }
            arr[j] = str;
        }
        
        for(int j = 0; j < 26; j++) {
            if(curr.children[j] != null) {
                TrieNode node = curr.children[j];
                char c = ALPHABET.charAt(j);
                array[tmp] = c;
                findWords(node, arr, array, ++tmp);
                array[tmp] = 0;
                tmp--;
            }
        }
    }
    
    //find words that differ by one letter from the given word
    public String[] differByOne(String word) {
        TrieNode current = root;
        String []arr = new String[100];
        char[] buff = new char[100];
        int i = 0;
        findWordsDifMax(current, arr, buff, 0, word, 1);
        return arr;
    }
    
    //find words that differ by max letters with the given word
    public String[] differBy(String word, int max) {
        TrieNode current = root;
        String []arr = new String[100];
        char[] buff = new char[100];
        int i = 0;
        int tmp = 0;
        
        findWordsDifMax(current, arr, buff, 0, word, max);
        return arr;   
    }
    
    //used in difby
    private void findWordsDifMax(TrieNode curr, String []arr, char[] array, int depth, String word, int max) {
       
        if(curr.isTerminal && depth == word.length()) {
            String str = "";
            for(int i = 0; array[i] != 0; i++) {
              str += array[i];  
            }
            int j;
            for(j = 0; arr[j] != null; j++) {
            }
            int tmp = compareStrings(str, word);
            tmp = word.length() - tmp;
            if(tmp > 0 && tmp <= max) {
                 arr[j] = str;
            }
        }
        if(depth == word.length() ) {
            return;
        }
       
        
        for(int j = 0; j < 26; j++) {
            if(curr.children[j] != null) {
                TrieNode node = curr.children[j];
                char c = ALPHABET.charAt(j);
                array[depth] = c;
                findWordsDifMax(node, arr, array, ++depth, word, max);
                array[depth] = 0;
                depth--;
            }
        }
    }
 
    //compares 2 strings and returns the number of same letters
    public int compareStrings(String str, String word) {
        int result = 0;
        char[] array = new char[word.length()];
        char[] arr = new char[word.length()];
        array = str.toCharArray();
        arr = word.toCharArray();
        for(int i =0; i < word.length(); i++) {
            if(array[i] == arr[i]) {
                result++;
            }
        }
        return result;
    }
   
    //prints the trie
    public String toString() {
        TrieNode curr = root;
        DisplayTrie(curr);
        
        return str1;
    }
    //used in tostring
    public String DisplayTrie(TrieNode curr) {
        int i;
        if(curr.isTerminal) {
             str1 += '!';
           
        }
       
        for(int j = 0; j < 26; j++) {
            if(curr.children[j] != null) {
                TrieNode node = curr.children[j];
                char c = ALPHABET.charAt(j);
                str1 += ' ';
                str1 += c;
                DisplayTrie(node);
            }
        }
        return str1;
    }
    
    public String toDotString() {
         TrieNode current = root; 
         dot = "graph Trie{\n\t";
         dot = dot + current.code;
         dot = dot + " [label=" +"\"ROOT\"" + " ,shape = circle, color = black]\n\t";
         
         for(int i =0; i < 26; i++) {
             if(current.children[i] != null) {
                dot = dot + current.code + " -- " + current.children[i].code + "\n\t";
                char c = ALPHABET.charAt(i);
                if(current.children[i].isTerminal == true) {
                    dot = dot + current.children[i].code + " [label=" +"\""+ c +"\"" + " ,shape = circle, color = red]\n\t";
                }
                else {
                    dot = dot + current.children[i].code + " [label=" +"\""+ c +"\"" + " ,shape = circle, color = black]\n\t";
                }
                dotString(current.children[i]);
             }
         }
         
         dot = dot + "}";
        
         return dot;
     }
    
    private void dotString(TrieNode curr) {
        int i;
        
        for(i = 0; i < 26; i++) {
            if(curr.children[i] != null) {
                char c;
                c = ALPHABET.charAt(i);
                dot = dot + curr.code + " -- " + curr.children[i].code + "\n\t";
                char ch = ALPHABET.charAt(i);
                if(curr.children[i].isTerminal == true) {
                    dot = dot + curr.children[i].code + " [label=" +"\""+ ch +"\"" + " ,shape = circle, color = red]\n\t";
                }
                else {
                    dot = dot + curr.children[i].code + " [label=" +"\""+ ch +"\"" + " ,shape = circle, color = black]\n\t";
                }
                dotString(curr.children[i]);
            }
        }
    }
     
}
