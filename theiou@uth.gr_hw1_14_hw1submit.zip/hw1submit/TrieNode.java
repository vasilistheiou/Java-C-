package ce326.hw1;

/**
 *
 * @author BASILIS
 */
public class TrieNode {
        TrieNode[] children;
        boolean isTerminal;
        int code;
        
        public TrieNode(){
            this.children = new TrieNode[26];
            int i;
            for(i = 0; i < 26; i++) {
                children[i] = null;
            }
            this.isTerminal = false;
            code = hashCode();
        }
}