/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author menios
 */
public class PPMImageStacker {
     List <PPMImage> fileList;
     PPMImage temp;
    
    
    public PPMImageStacker(java.io.File dir) throws FileNotFoundException,ce326.hw2.UnsupportedFileFormatException{
        
        if(dir.exists()==false){
            throw new FileNotFoundException("[ERROR] Directory" + " " + dir + " " + "does not exist!");
        }
        
        
        if(dir.isDirectory()==false){
           throw new ce326.hw2.UnsupportedFileFormatException("[ERROR]" + " " + dir+ " " + "is not a directory");
        }
        
        File[] listOfFiles = dir.listFiles();   //list the files to file array
        fileList=new ArrayList<>();
        
        int i=0;

        for (File file : listOfFiles) {
            
            try{
               PPMImage temporary=new PPMImage(file);   //add them to the list
               fileList.add(i,temporary);
               i++;
            }
            catch(FileNotFoundException ex){
                throw new FileNotFoundException("File not found!");
            }
            catch(ce326.hw2.UnsupportedFileFormatException ex){
                throw new ce326.hw2.UnsupportedFileFormatException("Not a PPM Image");
            }
            
        }
        
    }
        
    public void stack(){
        int width=fileList.get(0).getWidth();
        int height=fileList.get(0).getHeight();
        int sum_red=0;
        int sum_green=0;
        int sum_blue=0;
        int average_green=0;
        int average_red=0;
        int average_blue=0;
        int k;
        
        temp=fileList.get(0);
        temp.setWidth(width);
        temp.setHeight(height);
        
        for(int i = 0; i < height; i++){    //for every pixel in the same position of every pic find the average of all colors
            for(int j =0; j < width; j++){
                sum_red=0;
                sum_green=0;
                sum_blue=0;

                for(k =0; k < fileList.size(); k++){
                    sum_red += fileList.get(k).array[i][j].getRed();
                    sum_green+=fileList.get(k).array[i][j].getGreen();
                    sum_blue+=fileList.get(k).array[i][j].getBlue();
                }
                
		average_red = sum_red / (fileList.size());
                average_green=sum_green / (fileList.size());
                average_blue=sum_blue / (fileList.size());

		temp.array[i][j].setRed((short)average_red);
                temp.array[i][j].setGreen((short)average_green);
                temp.array[i][j].setBlue((short)average_blue);
                        
            }
	}

    }
    
    public PPMImage getStackedImage(){
        return temp;
    }
}
