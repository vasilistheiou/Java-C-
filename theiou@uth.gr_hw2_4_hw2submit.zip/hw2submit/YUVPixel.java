/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;

/**
 *
 * @author menios
 */
public class YUVPixel {
    private int pixel;
    
    
    
    //same as RGBPixels but this time Y U V
    
    public YUVPixel(short Y, short U, short V){
        pixel=0;
        pixel= Y;
        pixel = (pixel << 8) + U; 
        pixel=  (pixel << 8) + V;
        
    }
    
    public YUVPixel(YUVPixel pixel ){
        this.pixel=0;
        this.pixel=pixel.getY();
        this.pixel=(this.pixel << 8) + pixel.getU();
        this.pixel=(this.pixel << 8) + pixel.getV();
    }
    
    public YUVPixel(RGBPixel pixel){
       
        setY((short) ((short) ( (  66 * pixel.getRed() + 129 * pixel.getGreen() +  25 * pixel.getBlue() + 128) >> 8) +  16)); 
        setU((short) ((short) ( (short) ( -38 * pixel.getRed() -  74 * pixel.getGreen() + 112 * pixel.getBlue() + 128) >> 8) + 128)); 
        setV((short) ((short)( (short) ( 112 * pixel.getRed() -  94 * pixel.getGreen() -  18 * pixel.getBlue() + 128) >> 8) + 128));

    }
    
    public short getY(){
        return (short)(pixel >> 16);
    }

    public short getU(){
        return (short)((pixel >> 8) & 255); 
    }

    public short getV(){
        return (short)(pixel & 255); 
    }
    
    public short getY(int pixel){
        return (short)(pixel >> 16);
    }
    
    public short getU(int pixel){
        return (short)((pixel >> 8) & 255);
    }
    
    public short getV(int pixel){
        return (short)(pixel & 255);
    }
    
    
    //methods are final because we use them in the constuctor
    
    final void setY(short Y){
       int temp=0;
       temp=Y;
       temp=temp << 16;
       pixel=pixel & 0xFF00FFFF;
       pixel=pixel + temp;  
    }
    
    final void setU(short U){
       int temp=0;
       
       temp=U;
       
       temp=temp << 8;
       
       pixel=pixel & 0xFFFF00FF;
       
       pixel=pixel + temp;  
    }
    
    final void setV(short V){
       int temp=0;
       
       temp=V;
       
       pixel=pixel & 0xFFFFFF00;
       
       pixel=pixel + temp;  
    }
    
}
