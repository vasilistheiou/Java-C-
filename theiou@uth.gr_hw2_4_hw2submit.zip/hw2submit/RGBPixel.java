/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;

/**
 *
 * @author menios
 */
public class RGBPixel {
    
    private int pixel;

    
    public RGBPixel(short red,short green,short blue){  //making the appropriate shifts to create and R G B pixel
        pixel= 0;
        pixel= red;
        pixel = (pixel << 8) + green; 
        pixel=  (pixel << 8) + blue;
    
    }
    
    public RGBPixel(RGBPixel pixel){
        this.pixel=0;
        this.pixel=pixel.getRed();
        this.pixel=(this.pixel << 8) + pixel.getGreen();
        this.pixel=(this.pixel << 8) + pixel.getBlue();
        
    }
    
    public RGBPixel(YUVPixel pixel){
        short C = (short) (pixel.getY() - 16);
        short D = (short) (pixel.getU() - 128);
        short E = (short) (pixel.getV() - 128);

        setRed((short) clip(( 298 * C           + 409 * E + 128) >> 8));
        setGreen((short) clip(( 298 * C - 100 * D - 208 * E + 128) >> 8)); 
        setBlue((short) clip(( 298 * C + 516 * D           + 128) >> 8));

        
    }
    
    //shifts for getting each value
    public short getRed(){
        return (short)(pixel >> 16);
    }

    public short getGreen(){
        return (short)((pixel >> 8) & 255);
    }

    public short getBlue(){
        return (short)(pixel & 255); 
    }
    
    //shifts for setting each value(methods are final because we use them in the constructor)
    
    final void setRed(short red){
       int temp=0;
       temp=red;
       temp=temp << 16;
       pixel=pixel & 0xFF00FFFF;
       pixel=pixel + temp;  
    }
    
    final void setGreen(short green){
       int temp=0;
       
       temp=green;
       
       temp=temp << 8;
       
       pixel=pixel & 0xFFFF00FF;
       
       pixel=pixel + temp;  
    }
    
    
    
    final void setBlue(short blue){
       int temp=0;
       
       temp=blue;
       
       pixel=pixel & 0xFFFFFF00;
       
       pixel=pixel + temp;      
    }
    
    int getRGB(){
        return pixel;
    }
    
    void setRGB(int value){
        pixel=value;
    }
    
    final void setRGB(short red,short green,short blue){
        pixel= red;
        pixel = (pixel << 8) + green; 
        pixel=  (pixel << 8) + blue;
    }
    
    @Override
    public String toString(){
        return(String.valueOf(getRed()) + " " + String.valueOf(getGreen()) + " " + String.valueOf(getBlue()) + " ");
    }

    final int clip(int number){         //final because we use it in the constructor
        if(number<0){
            return 0;
        }
        if(number>255){
            return 255;
        }
        return number;
    }
    
}
