/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;

/**
 *
 * @author menios
 */
public class RGBImage implements Image {
    public static final int MAX_COLORDEPTH=255;
    private int width;
    private int height;
    private int colordepth;
    protected RGBPixel array[][];
    

    @Override
    
    //usage of the fixed algorithms and updating the picture
    
    public void grayscale() {   
        RGBPixel temp;
        short grey;
        
        for(int i=0;i<getHeight();i++){
            for(int j=0;j<getWidth();j++){
                temp=getPixel(i,j);
                grey=grey_convert(temp.getRed(),temp.getGreen(),temp.getBlue());
                temp.setRGB(grey,grey,grey);
            }
        }
    }
    
    

    @Override
    public void doublesize() {
        int newWidth=2*getWidth();
        int newHeight=2*getHeight();
        
        
     
        RGBPixel [][]newArray = new RGBPixel[newHeight][newWidth];

        for(int i = 0; i < getHeight(); i++){
            for(int j = 0; j < getWidth(); j++){
                RGBPixel temp=getPixel(i,j);

                newArray[2*i][2*j] = temp;
                newArray[2*i][2*j + 1] = temp;
                newArray[2*i + 1][2*j] = temp;
                newArray[2*i + 1][2*j + 1] = temp;

            } 
        }
    
        setHeight(newHeight);
        setWidth(newWidth);
        
        array=newArray;
  
        
    }

    @Override
    public void halfsize() {
        int newWidth=getWidth()/2;
        int newHeight=getHeight()/2;
        short red;
        short green;
        short blue;
               
        
     
        RGBPixel [][]newArray = new RGBPixel[newHeight][newWidth];

            for(int i = 0; i < newHeight; i++){
                for(int j = 0; j < newWidth; j++){
                    

                    red = (short)((int)array[2 * i][2 * j].getRed() +
                                  (int)array[2 * i][2 * j + 1].getRed() +
                                  (int)array[2 * i + 1][2 * j].getRed() +
                                  (int)array[2 * i][2 * j].getRed());
                    
                    red =  (short)((int)red / 4);

                    green = (short)((int)array[2 * i][2 * j].getGreen()+
                                    (int)array[2 * i][2 * j + 1].getGreen() +
                                    (int)array[2 * i + 1][2 * j].getGreen() +
                                    (int)array[2 * i][2 * j].getGreen());
                    
                    green = (short)((int)green / 4);

                    blue = (short)((int)array[2 * i][2 * j].getBlue() +
                                   (int) array[2 * i][2 * j + 1].getBlue() +
                                   (int)array[2 * i + 1][2 * j].getBlue() +
                                   (int)array[2 * i][2 * j].getBlue());
                    
                    blue = (short)((int)blue / 4);

                    newArray[i][j] = new RGBPixel(red, green, blue);
                }
    
            }
            
            setHeight(newHeight);
            
            setWidth(newWidth);
        
            array=newArray;
    }

    @Override
    public void rotateClockwise() {
        RGBPixel rot_array[][]=new RGBPixel[getWidth()][getHeight()];
        int newWidth=getHeight();
        int newHeight=getWidth();
        
        for(int rows=0;rows<getHeight();rows++){
            for(int col=0;col<getWidth();col++){
                rot_array[col][getHeight()-1-rows] = array[rows][col];
            }
        }
        
        array=rot_array;
        
        setWidth(newWidth);
        
        setHeight(newHeight);
    }
    public RGBImage(){
        array=null;
    }
    
    public RGBImage(int width, int height, int colordepth){
        this.width=width;
        this.height=height;
        this.colordepth=colordepth;
        
        array=new RGBPixel[this.height][this.width];
        
        for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
                array[i][j]=new RGBPixel((short)0,(short)0,(short)0);
            }
        }

    }
    
    public RGBImage(RGBImage copyImg){
        this.width=copyImg.getWidth();
        this.height=copyImg.getHeight();
        this.colordepth=copyImg.getColorDepth();
        
        array=new RGBPixel[this.height][this.width];
        
         
        for(int i=0;i<height;i++){
            System.arraycopy(copyImg.array[i], 0, this.array[i], 0, width);
        }
    }
    
    public RGBImage(YUVImage YUVImg){
       this.width=YUVImg.getWidth();
       this.height=YUVImg.getHeight();
       
       array=new RGBPixel[this.height][this.width];
       
       for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
                array[i][j]= new RGBPixel(YUVImg.YUVArray[i][j]);
            }
        }
    }
    
    int getWidth(){
        return this.width;
    }
    
    int getHeight(){
        return this.height;
    }
    
    int getColorDepth(){
        return this.colordepth;
    }
    
    void setWidth(int width){
        this.width=width;
    }
    
    void setHeight(int height){
        this.height=height;
    }
    
    void setColorDepth(int colordepth){
        this.colordepth=colordepth;
    }
    
    RGBPixel getPixel(int row, int col){
        return array[row][col];
    }
    
    
    void setPixel(int row, int col,RGBPixel pixel){
        array[row][col]=pixel;
    }
    
    short grey_convert(short Red,short Green,short Blue){
        return(short) (Red * 0.3 + Green * 0.59 + Blue * 0.11);
    }
    
  
}
