/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author menios
 */
public class YUVImage {
    protected YUVPixel YUVArray[][];
    private int width;
    private int height;
    
    
    public YUVImage(int width, int height){
        this.width=width;
        this.height=height;
        
        YUVArray=new YUVPixel[this.height][this.width];
        
        for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
                YUVArray[i][j]=new YUVPixel((short)16,(short)128,(short)128);
            }
        }
    }
    
    public YUVImage(YUVImage copyImg){
        YUVArray=new YUVPixel[this.height][this.width];
        
        this.width=copyImg.getWidth();
        this.height=copyImg.getHeight();
        this.YUVArray=copyImg.YUVArray;
        
    }
    
    public YUVImage(RGBImage RGBImg){
        this.width=RGBImg.getWidth();
        this.height=RGBImg.getHeight();
        
        YUVArray=new YUVPixel[this.height][this.width];
        
        for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
                YUVArray[i][j]= new YUVPixel(RGBImg.array[i][j]);
            }
        }
        

    }
    
    public YUVImage(java.io.File file) throws FileNotFoundException,ce326.hw2.UnsupportedFileFormatException{
        
        try(Scanner sc=new Scanner(file)){          //same as for ppm image
            
            if(sc.hasNext()==false || "YUV3".equals(sc.nextLine())==false){ //check if its not YUV
                throw new ce326.hw2.UnsupportedFileFormatException();
            }
            
            this.width=sc.nextInt();                                    //take the contents
            this.height=sc.nextInt();
        
        
            this.YUVArray=new YUVPixel[height][width];
                
            for(int i=0;i<height;i++){
                for(int j=0;j<width;j++){
                    short Y=(short) sc.nextInt();
                    short U=(short) sc.nextInt();
                    short V=(short) sc.nextInt();
                    this.YUVArray[i][j]=new YUVPixel(Y,U,V);
                }
            }
            
        }
        catch(FileNotFoundException ex){
            throw new FileNotFoundException("File not found");
        }
        
        catch(ce326.hw2.UnsupportedFileFormatException ex){
            throw new ce326.hw2.UnsupportedFileFormatException("Not a YUV Image");
        }
        
    }
    
    
    @Override
    public String toString(){   //save the picture in a file
        String file;
        
        file="YUV3\n";
        
        file=file + this.getWidth() + " " + this.getHeight() + "\n";
       
        
        for(int i=0;i<this.getHeight();i++){
            for(int j=0;j<this.getWidth();j++){
                file=file + YUVArray[i][j].getY() + " " + YUVArray[i][j].getU() + " " + YUVArray[i][j].getV() + "\t\n";
            }
        }
    
        return file;
    }
    
    public void toFile(java.io.File file){  //we use false to make the file empty
        
        try (FileWriter fWriter = new FileWriter(file, false)) {
          fWriter.write(toString());
        }catch(IOException ex){
            System.out.println("error with the file");                              
        }     
    }
    
    public void equalize(){         //change the luminocity based on the histogram
                
        Histogram eq=new Histogram(this);
        eq.equalize();
        
                
        for(int i=0;i<this.height;i++){
            for(int j=0;j<this.width;j++){
                YUVArray[i][j].setY(eq.getEqualizedLuminocity(YUVArray[i][j].getY()));
            }
        }
    }
            
    void setWidth(int width){
        this.width=width;
    }
    
    void setHeight(int height){
        this.height=height;
    }
    
    int getWidth(){
        return this.width;
    }
    int getHeight(){
        return this.height;
    }
}
