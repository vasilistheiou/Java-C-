/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author menios
 */
public class Histogram {
    int[] array;
    static final int MAX_LUMIN=235;
    int num;
    
    
    public Histogram(YUVImage img){         //get the luminocity and init the array
        num=img.getHeight()*img.getWidth();
        
        
        array=new int[MAX_LUMIN + 1];
        
        Arrays.fill(array,0);
        
        for(int i=0;i<img.getHeight();i++){
            for(int j=0;j<img.getWidth();j++){
                array[img.YUVArray[i][j].getY()]++;     //we find the number of pixels in each position
            }
        }
    }
    
    @Override
    public String toString(){               
        String str = null;
        int counter=0;
        
        for(int i:array){
            str=str + counter;
            for(int j=0;j<i/1000;j++)
                str=str + "#";
            
            for(int j=0;j<((i%1000)/100);j++)
                str=str + "$";
            
            for(int j=0;j<((i%1000)%100);j++)
                str=str + "*";
            
            str=str + "/n";
            counter++;
        }
        
        return(str);
    }
    
    public void toFile(java.io.File file){
        try (FileWriter fWriter = new FileWriter(file, false)) {    //false means we make it empty
          fWriter.write(toString());
        }catch(IOException ex){

            System.out.println("error with the file in Histogram");                              
        } 
    }
    
    public void equalize(){         //calculate pmf,cdf,making the appropriate calculations etc 
        int sum=0;
       
        for(int i=0;i<array.length;i++){
            array[i]=sum + array[i];
            sum=array[i];
            array[i]=(MAX_LUMIN * array[i])/num;
        }
    }
    
    public short getEqualizedLuminocity(int luminocity){    //get the new lum based on the "old" lum
         return (short)array[luminocity];
    }
}
