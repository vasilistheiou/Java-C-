/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;



/**
 *
 * @author menios
 */
public class PPMImage extends RGBImage{
    
    public PPMImage(java.io.File file) throws FileNotFoundException,UnsupportedFileFormatException{
        //default constructor call
        
        try(Scanner sc=new Scanner(file)){
            
            if(sc.hasNext()==false ||"P3".equals(sc.nextLine())==false){                  //check if the file starts with P3
                throw new ce326.hw2.UnsupportedFileFormatException();
            }
           
            int width=sc.nextInt();                                         
            int height=sc.nextInt();
            int depth=sc.nextInt();
            
            if(depth>MAX_COLORDEPTH){
                depth=255;
            }
        
            super.setWidth(width);                                  //set widht,height,colordepth for RGBImage
            super.setHeight(height);
            super.setColorDepth(depth);
        
            super.array=new RGBPixel[height][width];
                
            for(int i=0;i<height;i++){                             //take the file's contents
                for(int j=0;j<width;j++){
                    short red=(short) sc.nextInt();
                    short green=(short) sc.nextInt();
                    short blue=(short) sc.nextInt();
                    super.array[i][j]=new RGBPixel(red,green,blue);
                }
            }
        }
        catch(FileNotFoundException ex){
            throw new FileNotFoundException("File not found!");
        }
        catch(ce326.hw2.UnsupportedFileFormatException ex){
            throw new ce326.hw2.UnsupportedFileFormatException("Not a PPM Image");
        }
    
    }
    
    public PPMImage(RGBImage img){          //call the constuctor of the parent class
        super(img);
    }
    
    public PPMImage(YUVImage img){
        super(img);
    }
    
    @Override
    public String toString(){       
        String file;
        
        file="P3\n";
        
        file=file + super.getWidth() + " " + super.getHeight() + "\n" + "255\n";
       
        
        for(int i=0;i<super.getHeight();i++){
            for(int j=0;j<super.getWidth();j++){
                file=file + super.array[i][j].getRed() + " " + super.array[i][j].getGreen() + " " + super.array[i][j].getBlue() + "\t\n";
            }
        }
    
        return file;
        
    }
    
    public void toFile(java.io.File file){  //its false because we want it to be empty

        try (FileWriter fWriter = new FileWriter(file, false)) {
          fWriter.write(toString());
        }catch(IOException ex){
            System.out.println("error with the file");                              
        }   
    }
    
    @Override
    public int getWidth(){
        return(super.getWidth());
    }
    
    @Override
    public int getHeight(){
        return(super.getHeight());
    }
    
}
