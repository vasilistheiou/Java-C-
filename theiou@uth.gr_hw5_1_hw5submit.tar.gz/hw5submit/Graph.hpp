
#ifndef _GRAPH_HPP_ 
#define _GRAPH_HPP_
#include "NegativeGraphCycle.hpp"
#include <list>
#include <iostream>
#define INF 10000
#include<bits/stdc++.h>
  
using namespace std; 


typedef pair<int, int> priority_pair;

template<typename T>

struct Edge {
  T from;
  T to;
  int dist;
  int order;
  Edge(T f, T t, int d,int o): from(f), to(t), dist(d),order(o){
  }
  bool operator<(const Edge<T>& e) const{
    if(this->dist<e.dist){
      return true;
    }
    return false;
  }

  bool operator>(const Edge<T>& e) const{
    if(this->dist>e.dist){
      return true;
    }
    return false;
  }

  template<typename U>
  friend ostream& operator<<(ostream& out, const Edge<U>& e);
};

template<typename T>

struct Info {
  T in;
  Info(T info):in(info){}
  list<Edge<T>> inlist;
};

template<typename T>
std::ostream& operator<<(std::ostream& out, const Edge<T>& e) {
  out << e.from << " -- " << e.to << " (" << e.dist << ")";
  return out;
}

template <typename T>
class Graph {
public:
  vector<Info<T>> outerlist;
  bool isDirectedGraph;
  Graph(bool isDirectedGraph);
  bool contains(const T& info);
  bool addVtx(const T& info);
  bool rmvVtx(const T& info);
  bool addEdg(const T& from, const T& to, int distance);
  bool rmvEdg(const T& from, const T& to);
  list<T> dfs(const T& info);
  list<T> bfs(const T& info);
  list<Edge<T>> mst();
  void print2DotFile(const char *filename);
  list<T> dijkstra(const T& from, const T& to);
  list<T> bellman_ford(const T& from, const T& to);
  void recursion_dfs(int pos, vector<bool> &v,list<T> &queue);
  int getIndex(const T& info);
  void getPath(vector<int> &parent, int j,list<T> &output);
  void getSol(vector<int> &parent,list<T> &output,const T& from,const T& to);
  int getIndex(int i);
  T getInfo(int i);

  
};

template <typename T>
Graph<T>::Graph(bool isDirected) {
  this->isDirectedGraph=isDirected;
}

template <typename T>
bool Graph<T>::contains(const T& info) {
  typename vector<Info<T>> :: iterator it; 

  for(it = outerlist.begin(); it != outerlist.end(); ++it) {
    if((*it).in == info) 
      return true;
  }
  
  return false;
}

template <typename T>
bool Graph<T>::addVtx(const T& info) {
  
  if(contains(info))
    return false;
  
  
  this->outerlist.push_back(Info<T>(info));

  
  return true;
  
}

template <typename T>
bool Graph<T>::rmvVtx(const T& info) {
  typename vector<Info<T>> :: iterator it;
  typename list <Edge<T>> :: iterator it2;

  
  if(!contains(info))
    return false;


  for(it = outerlist.begin();it != outerlist.end(); ++it) {
    if((*it).in == info){
      outerlist.erase(it);
      break;
    }
  }
  
  for(it = outerlist.begin();it!=outerlist.end();++it){
    for(it2 = (*it).inlist.begin();it2!=(*it).inlist.end();){
      
      if((*it2).from==info || (*it2).to==info){
        it2=(*it).inlist.erase(it2);
      }
      else it2++;
    } 
  }
  
  return true;
  
}

template <typename T>
bool Graph<T>::addEdg(const T& from, const T& to, int distance) {
  typename vector <Info<T>> :: iterator it; 
  typename list <Edge<T>> :: iterator it2; 
  
  if(!contains(from))
    return false;
  
  if(!contains(to))
    return false;

  for(it = outerlist.begin(); it != outerlist.end(); ++it) {
    for(it2 = (*it).inlist.begin(); it2 != (*it).inlist.end(); ++it2) {
      if((*it2).to == to && (*it2).from == from) {
        return false;
      }
    }
  }
  
  for(it = outerlist.begin(); it != outerlist.end(); ++it) {
    if((*it).in==from){

      (*it).inlist.push_back(Edge<T>(from,to,distance,getIndex(to)));

      (*it).inlist.sort([](const Edge<T> & first, const Edge<T> & second) { return first.order< second.order; });

    }
    if((*it).in==to && isDirectedGraph==false){

      (*it).inlist.push_back(Edge<T>(to,from,distance,getIndex(from)));

      (*it).inlist.sort([](const Edge<T> & first, const Edge<T> & second) { return first.order< second.order; });
    }

  }

  return true;
  
}


template <typename T>
bool Graph<T>::rmvEdg(const T& from, const T& to) {
  typename vector <Info<T>> :: iterator it; 
  typename list <Edge<T>> :: iterator it2; 
  
  
  if(!contains(from))
    return false;
  
  if(!contains(to))
    return false;


  for(it = outerlist.begin();it!=outerlist.end();++it){
    if((*it).in==from){
      for(it2 = (*it).inlist.begin();it2!=(*it).inlist.end();){
        if((*it2).from==from && (*it2).to==to){
          it2=(*it).inlist.erase(it2);
        }
        else it2++;
      }
    }
    if((*it).in==to && isDirectedGraph==false){
      for(it2 = (*it).inlist.begin();it2!=(*it).inlist.end();){
        if((*it2).from==to && (*it2).to==from){
          it2=(*it).inlist.erase(it2);
        }
        else it2++;
      }
    }
  }
  return true;
}

template <typename T>

list<T> Graph<T>::dfs(const T& info){
  list<T> queue;
  vector<bool> v;

    for(int i = 0; i < (int)outerlist.size(); i++){
        v.push_back(false);
    }
  
    recursion_dfs(getIndex(info),v,queue); 

    return queue;
}


    
template <typename T>

list<T> Graph<T>::bfs(const T& info){
  typename vector<Info<T>>::iterator row=outerlist.begin();
  list<T> queue; 
  list<T> temp;
  vector<bool> v;
  T inf_temporary;


  for(int i = 0; i < (int)outerlist.size(); i++){
        v.push_back(false);
  }

  v.at(getIndex(info))=true;
  
  queue.push_back(info);
    
  typename list<Edge<T>>::iterator col;
    

  while(!queue.empty()){
   
      inf_temporary=queue.front();

      temp.push_back(inf_temporary); 

      queue.pop_front();

      advance(row,getIndex(inf_temporary));

      for (col = (*row).inlist.begin(); col != (*row).inlist.end(); ++col){
       
          if (!v.at(getIndex((*col).to))){

          
              v.at(getIndex((*col).to)) = true; 
              queue.push_back((*col).to); 
          } 
      }
      row=outerlist.begin();
  } 

    return temp;
}

template <typename T>

list<T> Graph<T>::dijkstra(const T& from, const T& to){
  list<T> output;
  priority_queue< priority_pair, vector <priority_pair> , greater<priority_pair> > pq; 
  vector<int> parent((int)outerlist.size(), -1);
  typename vector <Info<T>>::iterator row=outerlist.begin();

  vector<int> key((int)outerlist.size(), INF); 

  int src=getIndex(from);

  pq.push(make_pair(0, src)); 

  key[src] = 0; 

  while (!pq.empty()) 
  { 

      int u = pq.top().second;

      advance(row,u);

      if((*row).in==to){
          getSol(parent,output,from,to);
          return output;
      }

      pq.pop(); 


      typename list<Edge<T>>::iterator col;

      for (col = (*row).inlist.begin(); col != (*row).inlist.end(); ++col){
          int v = getIndex((*col).to);
          int weight;
          weight = (*col).dist ;

          if (key[v] > key[u] + weight){
              key[v] = key[u] + weight;

              parent[v]=u;

             pq.push(make_pair(key[v], v));
              
          }

      }
      
      row=outerlist.begin();

  } 
  

  if(key[getIndex(to)]==INF){
    return output;
  }

  getSol(parent,output,from,to);
  return output;
}


template<typename T>

list<T> Graph<T>::bellman_ford(const T& from, const T& to){
  vector<int> key((int)outerlist.size(), INF); 
  vector<int> parent((int)outerlist.size(), -1); 
  list<T> output;
  typename vector <Info<T>> :: iterator it; 
  typename list <Edge<T>> :: iterator it2; 
  T u;
  T v;
  int weight;

  key[getIndex(from)] = 0;


  for(int i=1;i<=(int)outerlist.size()-1;i++){
     for(it = outerlist.begin(); it != outerlist.end(); ++it) {
        for(it2 = (*it).inlist.begin(); it2 != (*it).inlist.end(); ++it2) {
          u=(*it2).from;
          v=(*it2).to;
          weight=(*it2).dist;

          if(key[getIndex(u)] !=INF && (key[getIndex(u)] + weight < key[getIndex(v)])){
                key[getIndex(v)] = key[getIndex(u)] + weight;
                parent[getIndex(v)]=getIndex(u);
          }
        }
      }   
  }

   for(it = outerlist.begin(); it != outerlist.end(); ++it) {
    for(it2 = (*it).inlist.begin(); it2 != (*it).inlist.end(); ++it2) {
      u=(*it2).from;
      v=(*it2).to;
      weight=(*it2).dist;

      if(key[getIndex(u)] !=INF && (key[getIndex(u)] + weight < key[getIndex(v)])){
            throw NegativeGraphCycle();
      }
    }
  } 

  getSol(parent,output,from,to);
  
  return output;
}
template <typename T>

list<Edge<T>> Graph<T>::mst(){
    list<Edge<T>> output; 
    typename vector <Info<T>>::iterator row=outerlist.begin();
    priority_queue< priority_pair, vector <priority_pair> , greater<priority_pair> > pq;
    int src = 0; 
    vector<int> key((int)outerlist.size(), INF); 

    vector<int> parent((int)outerlist.size(), -1); 

    vector<bool> mst_matrix((int)outerlist.size(), false); 

    pq.push(make_pair(0, src)); 

    key[src] = 0; 
    
    while (!pq.empty()) 
    { 

        int u = pq.top().second; 
        pq.pop(); 

        advance(row,u);
  
        mst_matrix[u] = true;  
  
        typename list <Edge<T>> :: iterator col; 

        for (col = (*row).inlist.begin(); col != (*row).inlist.end(); ++col){
            int v = getIndex((*col).to); 
            int weight = (*col).dist; 

            if (mst_matrix[v] == false && key[v] > weight){
                key[v] = weight; 
                pq.push(make_pair(key[v], v)); 
                parent[v] = u; 
            } 
        }
        row=outerlist.begin(); 
    } 
    
    for (int i = 1; i < (int)outerlist.size(); ++i){

     advance(row,parent[i]);

      if(getIndex((*row).in)<getIndex(i)){
        output.push_back(Edge<T>(getInfo(parent[i]),getInfo(i),key[i],0));
      }
      else output.push_back(Edge<T>(getInfo(i),getInfo(parent[i]),key[i],0));

      row=outerlist.begin();
    }
     
    return output;
}

template <typename T>

int Graph<T>:: getIndex(int i){
  typename vector <Info<T>>::iterator row=outerlist.begin();
  advance(row,i);

  return getIndex((*row).in);

}
template <typename T>

T Graph<T>::getInfo(int i){
  typename vector <Info<T>>::iterator row=outerlist.begin();
  advance(row,i);

  return (*row).in;

}

template <typename T>
void Graph<T>::getPath(vector<int> &parent, int j,list<T> &output){
  typename vector <Info<T>>::iterator row=outerlist.begin();
      
    if (parent[j] == - 1) 
        return; 
  
    getPath(parent, parent.at(j),output); 

    advance(row,j);
  
    output.push_back((*row).in);
} 
  
template <typename T>
void Graph<T>::getSol(vector<int> &parent,list<T> &output,const T& from,const T& to){
  typename vector <Info<T>>::iterator row=outerlist.begin();

    for (int i = 0; i < (int)outerlist.size(); i++) 
    { 
      advance(row,i);

      if((*row).in==to){
          output.push_back(from);
      
          getPath(parent, i,output); 
      }

      row=outerlist.begin();
    } 
}

 template<typename T>
 void Graph<T>::print2DotFile(const char *filename){
    typename vector <Info<T>>::iterator row;
    ofstream newfile;
    newfile.open (filename);

    newfile<<"digraph {\n";

    for(row = outerlist.begin(); row != outerlist.end(); ++row) {
      for(auto& it2:(row)->inlist) {

        if(it2.to==(row)->inlist.front().to){
            newfile<<(row)->in<<" [label="<<"\""<<(row)->in<<"\" "<<"shape=circle, color=black]\n";
        }

        else newfile<<"\t"<<(row)->in<<" -> "<<it2.to<<endl;

      }
    }
      newfile<<"}";
 }

template<typename T>
void Graph<T>::recursion_dfs(int pos, vector<bool> &v,list<T> &queue){
   typename vector<Info<T>>::iterator row=outerlist.begin();
   v.at(pos)= true; 

   advance(row,pos);

   queue.push_back((*row).in);

   typename list<Edge<T>>::iterator col;

   row=outerlist.begin();

   advance(row,pos);
 
   for (col = (*row).inlist.begin(); col != (*row).inlist.end(); ++col)
        if (!v.at( getIndex((*col).to)))
            recursion_dfs(getIndex((*col).to),v,queue); 
} 

 template<typename T>

int Graph<T>::getIndex(const T& info){
  typename vector <Info<T>> :: iterator it; 
  int counter=0;

  for(it = outerlist.begin();it!=outerlist.end();++it){
    if((*it).in==info){
      return counter;
    }
    counter++;

  }
  return 0;
}

#endif