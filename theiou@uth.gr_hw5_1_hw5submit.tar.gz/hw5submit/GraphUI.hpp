
#ifndef _GRAPH_UI_
#define _GRAPH_UI_

template <typename T>
int graphUI() {
  
  string option, line;
  bool digraph = false;
  
  cin >> option;
  if(!option.compare("digraph"))
    digraph = true;
  Graph<T> g(digraph);
  
  while(true) {
    
    std::stringstream stream;
    cin >> option;
    
    if(!option.compare("av")) {
      
      getline(std::cin, line);

      stream << line;

      T vtx(stream);

      if(g.addVtx(vtx))
        cout << "av " << vtx << " OK\n";
      else
        cout << "av " << vtx << " NOK\n";
    }
    else if(!option.compare("rv")) {
      getline(std::cin, line);

      stream << line;

      T vtx(stream);

      if(g.rmvVtx(vtx))
        cout << "rv " << vtx << " OK\n";
      else
        cout << "rv " << vtx << " NOK\n";

    }
    else if(!option.compare("ae")) {
      getline(std::cin, line);

      int dist=0;

      stream << line;

      T from(stream);
 
      T to(stream);

      stream>>dist;
     
      if(g.addEdg(from,to,dist))
        cout << "ae " << from <<" "<< to << " OK\n";
      else
        cout << "ae " << from <<" "<< to <<  " NOK\n";

    }
    else if(!option.compare("re")) {
      getline(std::cin, line);

      stream << line;

      T from(stream);

      T to(stream);

      if(g.rmvEdg(from,to))
        cout << "re " << from <<" " << to << " OK\n";
      else
        cout << "re " << from <<" " << to <<  " NOK\n";

    }

    else if(!option.compare("dot")) {
      getline(std::cin, line);

      stream << line;

      string name;

      stream >> name;

      g.print2DotFile(name.c_str());

      cout << "dot " << name << " OK\n";
      
    }
    else if(!option.compare("bfs")) {

      getline(std::cin, line);

      stream << line;

      T vtx(stream);

      list<T> print_list;

      cout << "\n----- BFS Traversal -----\n";

      print_list=g.bfs(vtx);

      cout<<print_list.front();

      print_list.pop_front();

      for(auto print : print_list){

         cout<<" -> "<<print;
      }

      cout << "\n-------------------------\n";
    }
    else if(!option.compare("dfs")) {
      getline(std::cin, line);

      stream << line;

      T vtx(stream);

      list<T> print_list;

      cout << "\n----- DFS Traversal -----\n";

      print_list=g.dfs(vtx);

      cout<<print_list.front();

      print_list.pop_front();


      for(auto print : print_list)
         cout<<" -> "<<print;


      cout << "\n-------------------------\n";
    }
    else if(!option.compare("dijkstra")) {
      getline(std::cin, line);
      stream << line;

      T from(stream);
 
      T to(stream);

      list<T> print_list;

      print_list=g.dijkstra(from,to);


      cout << "Dijkstra (" << from << " - " << to <<"): ";

      if(print_list.empty()==true){

        cout<<endl;

        continue;
      }

      cout<<print_list.front();

      print_list.pop_front();

      for(auto print : print_list)
         cout<<", "<<print;

      cout<<endl;

      
    }
    else if(!option.compare("bellman-ford")) {
      getline(std::cin, line);
      stream << line;

      T from(stream);
 
      T to(stream);

      list<T> print_list;

      cout << "Bellman-Ford (" << from << " - " << to <<"): ";

      try{

        print_list=g.bellman_ford(from,to);
      }

      catch(NegativeGraphCycle& ex){
        cout<<ex.what()<<endl;
        continue;
      }

      cout<<print_list.front();

      print_list.pop_front();

      for(auto print : print_list)
         cout<<", "<<print;

     cout<<endl;

      
    }
    else if(!option.compare("mst")) {
      int sum=0;

      list<Edge<T>> print_list;

      print_list=g.mst();

      print_list.sort();

      cout << "\n--- Min Spanning Tree ---\n";

      cout<<print_list.front();

      cout<<endl;

      sum=print_list.front().dist;

      print_list.pop_front();

      for(auto print : print_list){
         cout<<print;
         cout<<endl;
         sum = sum + print.dist;
      }

      cout << "MST Cost: " << sum << endl;
    }
    else if(!option.compare("q")) {
      cerr << "bye bye...\n";
      return 0;
    }
    else if(!option.compare("#")) {
      string line;
      getline(cin,line);
      cerr << "Skipping line: " << line << endl;
    }
    else {
      cout << "INPUT ERROR\n";
      return -1;
    }
  }
  return -1;  
}

#endif
