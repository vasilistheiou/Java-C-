#include "AVL.hpp"
#include <cstdlib>
#include <fstream>
#include <stack>
#include <iostream>

using namespace std;

AVL::Node::Node(const string& e, Node *parent, Node *left, Node *right) { 
	this->element = e;
	this->parent = parent;
	this->left = left;
	this->right = right;
	this->height = 1;
}

AVL::Node* AVL::Node::getParent() const {
	return this->parent;
}

AVL::Node* AVL::Node::getLeft() const {
	return this->left;
}

AVL::Node* AVL::Node::getRight() const {
	return this->right;
}

string AVL::Node::getElement() const {
	return this->element;
}

int AVL::Node::getHeight() const {
	if(this != nullptr) {
		return this->height;
	}
	
	return 0;
}

void  AVL::Node::setLeft(Node *node) {
	this->left = node;
}

void  AVL::Node::setRight(Node *node) {
	this->right = node;
}

void  AVL::Node::setParent(Node *node) {
	this->parent = node;
}

void  AVL::Node::setElement(string e) {
	this->element = e;
}

void AVL::Node::setHeight(int a) {
	this->height = a;
}

bool  AVL::Node::isLeft() const {
	
	Node *tmp;
	tmp = this->parent;
	
	if(tmp == nullptr) { 
		return false;
	}
	
	if(tmp->getLeft() == this) {
		return true;
	}
	
	return false;
}

bool  AVL :: Node :: isRight() const {
	
	if(this->parent == nullptr) { 
		return false;
	}
	
	if(this->parent->getRight() == this) {
		return true;
	}
	
	return false;
}

int AVL :: Node :: rightChildHeight() const {
	
	if(this->getRight() != nullptr) {
		return  this->right->getHeight();
	}
	
	return 0;
}

int AVL :: Node :: leftChildHeight() const {
	
	if(this->getLeft() != nullptr) {
		return  this->left->getHeight();
	}
	
	return 0;
}

int AVL :: Node :: updateHeight() {
	
		if(this->getLeft() == nullptr && this->getRight() == nullptr) {
			return 1;
		}
		else if(this->getLeft() == nullptr && this->getRight() != nullptr) {
			this->height = this->getRight()->getHeight() + 1;
		}
		else if (this->getLeft() != nullptr && this->getRight() == nullptr) {
			this->height = this->getLeft()->getHeight() + 1;
		}
		else if(this->getRight()->getHeight() > this->getLeft()->getHeight()) {
			this->height = this->getRight()->getHeight() + 1;
		}
		else {//if left height > or =
			this->height  = this->getLeft()->getHeight() + 1;
		}
	return this->height;
}

bool AVL :: Node :: isBalanced() {
	
	if(this->getLeft() == nullptr && this->getRight() == nullptr) {
		return true;
	}
	else if(this->getLeft() == nullptr && this->getRight() != nullptr) {
		if(this->getRight()->getHeight() <= 1) {
			return true;
		}
		
		return false;
	}
	else if(this->getLeft() != nullptr && this->getRight() == nullptr) {
		if(this->getLeft()->getHeight() <= 1) {
			return true;
		}
		
		return false;
	}
	else {
		if(abs(left->height - right->height) <= 1) {
			return true;
		}
		
	}
	
	return false;
	
}

AVL :: AVL() {
	this->root = nullptr;
	this->size = 0;
}

AVL :: AVL(const AVL& avl) {
	
	this->root = nullptr;
	this->size = 0;
	
	addTree(avl.root);
	
	
}

AVL::Node* AVL::find_node(string name, Node* start) {
	
	if(start == nullptr) {
		return start;
	}
	
	if(name.compare(start->getElement()) == 0) {
		return start;
	}
	else if(name.compare(start->getElement()) < 0) {
		start = find_node(name, start->getLeft());
	}
	else if(name.compare(start->getElement()) > 0) {
		start = find_node(name, start->getRight());
	}
	
	return start;
}

bool AVL :: contains(string e) {
	Node* tmp;
	tmp = find_node(e, this->root);
	
	if(tmp == nullptr) {
		return false;
	}
	return true;
}


AVL::Node* AVL::insert(Node* node, Node* n, string e) {
	Node* tmp;
	
	if (node == nullptr) {
		tmp = new Node(e, n, nullptr, nullptr);
		tmp->setHeight(1);
		return tmp;
	}
	
	if (e.compare(node->getElement()) < 0) { 
		node->setLeft(insert(node->getLeft(), node,e));
	}
	else if (e.compare(node->getElement()) > 0) {  
		node->setRight(insert(node->getRight(), node,e));
	}
	else {
		return node; 
	}
	node->setHeight(1 + max(node->getLeft()->getHeight(), node->getRight()->getHeight()));
	
	int balance = getBalance(node);
	
	if (balance > 1 && e.compare(node->getLeft()->getElement()) < 0)  
		return rightRotate(node);  
	
	if (balance < -1 && e.compare(node->getRight()->getElement()) > 0)  
		return leftRotate(node);
	 
	if (balance > 1 && e.compare( node->getLeft()->getElement()) > 0) {  
		node->setLeft(leftRotate(node->getLeft()));  
		return rightRotate(node);  
	}  
	 
	if (balance < -1 && e.compare(node->getRight()->getElement()) < 0) {  
		node->setRight(rightRotate(node->getRight()));  
		return leftRotate(node);  
	}
	
	return node;
	
}

AVL::Node* AVL::leftRotate(Node *x) {  
	Node *y = x->getRight();  
	Node *T2 = y->getLeft();
	
	y->setLeft(x);  
	x->setRight(T2);
	
	x->setHeight(max(x->getLeft()->getHeight(), x->getRight()->getHeight()) + 1);  
	y->setHeight(max(y->getLeft()->getHeight(), y->getRight()->getHeight()) + 1);
	return y;  
}  

AVL::Node* AVL::rightRotate(Node *y) {  
	Node *x = y->getLeft();  
	Node *T2 = x->getRight();  
	
	x->setRight(y); 
	y->setLeft(T2);  
	
	y->setHeight(max(y->getLeft()->getHeight(), y->getRight()->getHeight()) + 1);  
	x->setHeight(max(x->getLeft()->getHeight(), x->getRight()->getHeight()) + 1);  
	
	return x;  
} 

int AVL::max(int a, int b) {  
	return (a > b)? a : b;  
}  

bool AVL::add(string e) {
	bool check;
	
	check = contains(e);
	if(check) {
		return false;
	}
	
	root = insert(this->root,this->root, e);
	
	return true;
}

bool AVL::rmv(string e) {
	bool check;
	
	check = contains(e);
	if(check == false) {
		return false;
	}
	
	this->root = remove_node(this->root, e);
	return true;
	
}

int AVL::getBalance(Node *N) {  
	
	if (N == NULL) {  
		return 0;
	}
	return N->getLeft()->getHeight() - N->getRight()->getHeight();  
}

AVL::Node* AVL::minValueNode(Node* node) {  
	Node* current = node;  
	
	/* loop down to find the leftmost leaf */
	while (current->getLeft() != NULL)  
		current = current->getLeft();  
	
	return current;  
}  

AVL::Node* AVL::remove_node(Node* node, string key) {
	int balance;
	
	if(node == nullptr) {
		return node;
	}
	
	if(key.compare(node->getElement()) < 0) {
		node->setLeft(remove_node(node->getLeft(), key));
	}
	else if(key.compare(node->getElement()) > 0) {
		node->setRight(remove_node(node->getRight(), key));
	}
	
	else {
		if(node->getLeft() == nullptr || node->getRight() == nullptr) {
			Node* tmp = node->getLeft() ? node->getLeft() : node->getRight();
			if(tmp == nullptr) {
				tmp = node;
				node = nullptr;
			}
			else {
				*node = *tmp;
			}
			
			free(tmp);
		}
		else {
			Node* tmp = minValueNode(node->getRight());
			node->setElement(tmp->getElement());  
			node->setRight(remove_node(node->getRight(), tmp->getElement()));  
			
		}
	}
	if (node == nullptr) {   
		return node;
	}
	
	node->setHeight(1 + max(node->getLeft()->getHeight(), node->getRight()->getHeight()));  
	
	balance = getBalance(node);
	
	if (balance > 1 &&  getBalance(node->getLeft()) >= 0)  
		return rightRotate(node);  
	
    // Left Right Case  
	if (balance > 1 && getBalance(node->getLeft()) < 0) {  
		node->setLeft(leftRotate(node->getLeft()));  
		return rightRotate(node);  
	}  
    
    // Right Right Case  
	if (balance < -1 && getBalance(node->getRight()) <= 0) { 
		return leftRotate(node);  
	}
	// Right Left Case  
	if (balance < -1 && getBalance(node->getRight()) > 0) {  
		node->setRight(rightRotate(node->getRight()));  
		return leftRotate(node);  
	}  
	
	return node;  
}

void AVL::pre_order(std::ostream& out){
	
	pre(this->root, out);
	
}

void AVL::pre(Node* node, std::ostream& out) const{
	
	if(node == nullptr) {
		return;
	}
	
	out << node->getElement() << " ";
	
	if(node->getLeft() != nullptr) {
		pre(node->getLeft(), out);
	}
	
	if(node->getRight() != nullptr) {
		pre(node->getRight(), out);
	}
	
}

void AVL::print2DotFile(char *filename) {
	
	ofstream dotFile;
	string str = "";
  
	str += "digraph AVLTree {\n";
	str += "fontcolor=\"navy\"\n";
	str += "fontsize=20\n";
	str += "labelloc=\"t\"\n";
	str += "label=\"AVL Tree\"\n";
	str += dotStr(this->root);
	str += "}";
  
	dotFile.open(filename);
	dotFile << str;
	dotFile.close();
}

string AVL::dotStr(Node* node) {
	string str = "";
	
	if(node == nullptr) {
		return "";
	}
	
	str += node->getElement() + " [label=\"" + node->getElement() + "\", shape=circle, color=black]\n";
	
	if(node->getLeft() != nullptr) {
		str += node->getElement() + " -> " + node->getLeft()->getElement() + "\n";
	}
	
	str += dotStr(node->getLeft());
	
	if(node->getRight() != nullptr) {
		str += node->getElement() + " -> " + node->getRight()->getElement() + "\n";
	}
	
	str += dotStr(node->getRight());
	
	return str;
}

std::ostream& operator<<(std::ostream& out, const AVL& tree) {
	tree.pre(tree.root, out);
	
	return out;
}

void AVL::addTree(Node* node) {
	
	if(node == nullptr) {
		return;
	}
	
	this->add(node->getElement());
	
	addTree(node->getLeft());
	addTree(node->getRight());
}

AVL& AVL::operator  =(const AVL& avl) {
	
	this->root = nullptr;
	this->size = 0;
	
	this->addTree(avl.root);
	
	return *this;
}

AVL AVL::operator  +(const AVL& avl) {
	AVL tmp;
	
	tmp.addTree(this->root);
	tmp.addTree(avl.root);
	
	return tmp;
}

AVL& AVL::operator +=(const AVL& avl) {
	
	this->addTree(avl.root);
	
	return *this;
}

AVL& AVL::operator +=(const string& e) {
	
	this->add(e);
	
	return *this;
}

AVL& AVL::operator -=(const string& e) {
	  
	this->rmv(e);
	
	return *this;
}

AVL  AVL::operator  +(const string& e) {
	
	AVL tmp(*this);
	
	tmp.add(e);
	
	return tmp;
}

AVL  AVL::operator  -(const string& e) {
	AVL tmp(*this);
	
	tmp.rmv(e);
	
	return tmp;
}

AVL::Iterator::Iterator() {
	this->curr = nullptr;
}

AVL::Iterator::Iterator(Node *node) {
	this->curr = node;
	nodeStack.push(this->curr);
}

AVL::Iterator::Iterator(const Iterator& tmp) {
	this->curr = tmp.curr;
	this->nodeStack = tmp.nodeStack;
}

bool AVL::Iterator::hasNext() {
	return !nodeStack.empty();
}

void AVL::Iterator::next() {
	if(!hasNext()) {
		return;
	}
	
	nodeStack.pop(); 
	
	if(this->curr->getRight() != nullptr) {
		nodeStack.push(this->curr->getRight());
	}
	if(this->curr->getLeft() != nullptr) {
		nodeStack.push(this->curr->getLeft());
	}
	
	curr = nodeStack.top();
	
}
AVL::Iterator& AVL::Iterator::operator++() {
	this->next();
	
	return *this;
}

AVL::Iterator AVL::Iterator::operator++(int a) {
	Iterator tmp(*this);
	
	this->next();
	
	return tmp;
}

string AVL::Iterator::operator*() {
	return this->curr->getElement();
}

bool AVL::Iterator::operator!=(Iterator it) {
	
	if(this->curr != it.curr) {
		return true;
	}
	
	return false;
}

bool AVL::Iterator::operator==(Iterator it) {
	if(this->curr == it.curr) {
		return true;
	}
	
	return false;
}

AVL::Iterator AVL::begin() const {
	Iterator it(this->root);
	
	return it;
}

AVL::Iterator AVL::end() const {
	Iterator it(nullptr);
	
	return it;
}
