#ifndef __AVL_HPP_
#define __AVL_HPP_

#include <iostream>
#include <fstream>
#include <stack>


using namespace std;

class AVL {
private:
  class Node {
    Node *parent, *left, *right;
    int height;
    string element;

  public:
    Node(const string& e, Node *parent, Node *left, Node *right);
    Node*  getParent() const;
    Node*  getLeft() const;
    Node*  getRight() const;
    string getElement() const;
    int    getHeight() const;
  
    void setLeft(Node *);
    void setRight(Node *);
    void setParent(Node *);
    void setElement(string e);
	void setHeight(int a);
	bool isLeft() const;
    bool isRight() const;
    int  rightChildHeight() const;
    int  leftChildHeight() const;
    int  updateHeight();
    bool isBalanced();
  };
private:
  
  int   size;
  Node* root;
  
public:
    
    class Iterator {
	
	std::stack <Node*> nodeStack;
	Node *curr;
	
    public:
		Iterator();
		Iterator(Node *);
		Iterator(const Iterator& );
		Iterator& operator++();
		Iterator operator++(int a);
		string operator*(); 
		bool operator!=(Iterator it);
		bool operator==(Iterator it);
	  
	private:
		bool hasNext();
		void next();
    };
    
  Iterator begin() const;  
  Iterator end() const;
  
  static const int MAX_HEIGHT_DIFF = 1;
  AVL();
  AVL(const AVL& );
  bool contains(string e);
  Node* find_node(string name, Node* start);
  bool add(string e);
  Node* insert(Node* node, Node* n, string e);
  Node* leftRotate(Node* x);
  Node* rightRotate(Node* y);
  int max(int a, int b);
  bool rmv(string e);
  int getBalance(Node* N);
  Node* remove_node(Node* node, string key);
  Node* minValueNode(Node* node);
  void print2DotFile(char *filename);
  string dotStr(Node* node);
  void pre_order(std::ostream& out);
  void pre(Node *node, std::ostream& out) const;
  void addTree(Node* node);
  
  friend std::ostream& operator<<(std::ostream& out, const AVL& tree);  
  AVL& operator  =(const AVL& avl);
  AVL  operator  +(const AVL& avl);
  AVL& operator +=(const AVL& avl);
  AVL& operator +=(const string& e);
  AVL& operator -=(const string& e);
  AVL  operator  +(const string& e);
  AVL  operator  -(const string& e);
};

#endif
